# PHP-wtl

same database as jsp 

note: C:/php/ext/

https://user-images.githubusercontent.com/62329500/164615120-bb900d0e-718e-49fc-9dc0-db792263e9cf.png
https://user-images.githubusercontent.com/62329500/164615149-9cc12e8e-e5c0-41bf-9f5a-2096d150d8fa.png
https://user-images.githubusercontent.com/62329500/164615196-8fa6f485-1a6e-4bcd-9429-b991a831314c.png
https://user-images.githubusercontent.com/62329500/164615279-3fa88708-914d-4344-8137-a70383c753ed.png
https://user-images.githubusercontent.com/62329500/164615316-4a698b9b-1f60-42e1-9083-af8916b262de.png
