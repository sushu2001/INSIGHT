Use wildfly 18 application server-install server zip file from internet
use it configure server runtime
Calcualte.zip is the EJB interface
Calculator.zip is a servlet which accesses the EJB interface
