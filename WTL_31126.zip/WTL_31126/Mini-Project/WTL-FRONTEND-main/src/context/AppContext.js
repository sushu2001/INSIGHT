import React from 'react'

const AppContext = new React.createContext();

export {AppContext}